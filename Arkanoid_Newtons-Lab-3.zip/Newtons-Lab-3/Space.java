import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Space. The final frontier. 
 * 
 * @author Michael K�lling
 * @version 1.2
 */
public class Space extends World
{
    private String soundFiles = "3b" ;
    
    /**
     * Constructor for objects of class Space.
     * 
     */
    public Space()
    {    
        super(960, 620, 1);
        
        createObstacles();
        randomBodies(1);
        
        addObject (new Barra(), 480, 580);
    }
    
    /**
     * Create a row of obstacles across the middle of our world.
     */
    public void createObstacles()
    {
        int i = 0;
        while (i < 14) 
        {
            addObject (new Obstacle (soundFiles + ".wav"), 80 + i*60, 110);
            addObject (new Obstacle (soundFiles + ".wav"), 80 + i*60, 180);
            i++;
        }
    }
    
    /**
     * Create a given number of bodies in the universe. Each body has a random initial state (size,
     * mass, direction, speed, color, location).
     */
    public void randomBodies(int number)
    {
        while (number > 0) 
        {
            int size = 30 ;
            double mass = size * 7.0;
            int direction = 180+ Greenfoot.getRandomNumber(150);
            double speed = 50;
            int x = 480;
            int y = 550;
            int r =  Greenfoot.getRandomNumber(255);
            int g =  Greenfoot.getRandomNumber(255);
            int b =  Greenfoot.getRandomNumber(255);
            addObject (new Body (size, mass, new Vector(direction, speed), new Color(r, g, b)), x, y);
            number--;
        }
    }
}
